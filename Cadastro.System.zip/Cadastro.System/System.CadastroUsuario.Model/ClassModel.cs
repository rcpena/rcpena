﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.CadastroUsuario.DAO;
using System.CadastroUsuario.Entity;

namespace System.CadastroUsuario.Model
{
    public class ClassModel
    {
        public void NewUser()
        {
            try
            {
                Clusuario objusu = new Clusuario();
                
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
    
}
