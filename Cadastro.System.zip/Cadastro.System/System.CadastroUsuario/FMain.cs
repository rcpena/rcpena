﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.CadastroUsuario.Model;
using System.CadastroUsuario.Entity;

namespace System.CadastroUsuario
{
    public partial class FMain : Form
    {
        public FMain()
        {
            InitializeComponent();
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {
            
        }

        private void sairToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void novoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.CadastroUsuario.FCadastroUsuário form = new System.CadastroUsuario.FCadastroUsuário();
            form.Show();
        }
    }
}
