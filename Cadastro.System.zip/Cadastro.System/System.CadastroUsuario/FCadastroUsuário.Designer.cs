﻿
namespace System.CadastroUsuario
{
    partial class FCadastroUsuário
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tControlCadUsuario = new System.Windows.Forms.TabControl();
            this.tPageCadUsuario = new System.Windows.Forms.TabPage();
            this.btAdicNovoEnderCadUsu = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.mskTxtDtNascCadUsu = new System.Windows.Forms.MaskedTextBox();
            this.lblMuniCadUsu = new System.Windows.Forms.Label();
            this.lblUfCadUsu = new System.Windows.Forms.Label();
            this.txtUfcadUsu = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblBairroCadUsu = new System.Windows.Forms.Label();
            this.txtBairroCadUsu = new System.Windows.Forms.TextBox();
            this.lblComplCadUsu = new System.Windows.Forms.Label();
            this.txtComplCadUsu = new System.Windows.Forms.TextBox();
            this.lblNumCadUsu = new System.Windows.Forms.Label();
            this.txtNumCadUsu = new System.Windows.Forms.TextBox();
            this.txtLogradCadUsu = new System.Windows.Forms.TextBox();
            this.lblLogradCadUsu = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.lblCepCadUsu = new System.Windows.Forms.Label();
            this.mskTxtTelCadUsu = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmailCadUsu = new System.Windows.Forms.Label();
            this.txtNomCadUsu = new System.Windows.Forms.TextBox();
            this.lblNomCadUsu = new System.Windows.Forms.Label();
            this.txtIdCadUsu = new System.Windows.Forms.TextBox();
            this.lblCodCadUsu = new System.Windows.Forms.Label();
            this.rbtEnderComCadUsu = new System.Windows.Forms.RadioButton();
            this.rbtEnderResidCadUsu = new System.Windows.Forms.RadioButton();
            this.tCadaUsuarioEnder = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btNovoUsuCad = new System.Windows.Forms.Button();
            this.btConsUsuCad = new System.Windows.Forms.Button();
            this.btAltUsuCad = new System.Windows.Forms.Button();
            this.btExclUsuCad = new System.Windows.Forms.Button();
            this.btFechaFormCadUsu = new System.Windows.Forms.Button();
            this.btConfirmCadUsu = new System.Windows.Forms.Button();
            this.btCancelCadUsu = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.tControlCadUsuario.SuspendLayout();
            this.tPageCadUsuario.SuspendLayout();
            this.tCadaUsuarioEnder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 516);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(678, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(113, 17);
            this.toolStripStatusLabel1.Text = "Cadastro de Usuário";
            // 
            // tControlCadUsuario
            // 
            this.tControlCadUsuario.Controls.Add(this.tPageCadUsuario);
            this.tControlCadUsuario.Controls.Add(this.tCadaUsuarioEnder);
            this.tControlCadUsuario.Location = new System.Drawing.Point(12, 83);
            this.tControlCadUsuario.Name = "tControlCadUsuario";
            this.tControlCadUsuario.SelectedIndex = 0;
            this.tControlCadUsuario.Size = new System.Drawing.Size(653, 367);
            this.tControlCadUsuario.TabIndex = 1;
            // 
            // tPageCadUsuario
            // 
            this.tPageCadUsuario.Controls.Add(this.btAdicNovoEnderCadUsu);
            this.tPageCadUsuario.Controls.Add(this.label2);
            this.tPageCadUsuario.Controls.Add(this.mskTxtDtNascCadUsu);
            this.tPageCadUsuario.Controls.Add(this.lblMuniCadUsu);
            this.tPageCadUsuario.Controls.Add(this.lblUfCadUsu);
            this.tPageCadUsuario.Controls.Add(this.txtUfcadUsu);
            this.tPageCadUsuario.Controls.Add(this.textBox2);
            this.tPageCadUsuario.Controls.Add(this.lblBairroCadUsu);
            this.tPageCadUsuario.Controls.Add(this.txtBairroCadUsu);
            this.tPageCadUsuario.Controls.Add(this.lblComplCadUsu);
            this.tPageCadUsuario.Controls.Add(this.txtComplCadUsu);
            this.tPageCadUsuario.Controls.Add(this.lblNumCadUsu);
            this.tPageCadUsuario.Controls.Add(this.txtNumCadUsu);
            this.tPageCadUsuario.Controls.Add(this.txtLogradCadUsu);
            this.tPageCadUsuario.Controls.Add(this.lblLogradCadUsu);
            this.tPageCadUsuario.Controls.Add(this.maskedTextBox1);
            this.tPageCadUsuario.Controls.Add(this.lblCepCadUsu);
            this.tPageCadUsuario.Controls.Add(this.mskTxtTelCadUsu);
            this.tPageCadUsuario.Controls.Add(this.label1);
            this.tPageCadUsuario.Controls.Add(this.txtEmail);
            this.tPageCadUsuario.Controls.Add(this.lblEmailCadUsu);
            this.tPageCadUsuario.Controls.Add(this.txtNomCadUsu);
            this.tPageCadUsuario.Controls.Add(this.lblNomCadUsu);
            this.tPageCadUsuario.Controls.Add(this.txtIdCadUsu);
            this.tPageCadUsuario.Controls.Add(this.lblCodCadUsu);
            this.tPageCadUsuario.Controls.Add(this.rbtEnderComCadUsu);
            this.tPageCadUsuario.Controls.Add(this.rbtEnderResidCadUsu);
            this.tPageCadUsuario.Location = new System.Drawing.Point(4, 22);
            this.tPageCadUsuario.Name = "tPageCadUsuario";
            this.tPageCadUsuario.Padding = new System.Windows.Forms.Padding(3);
            this.tPageCadUsuario.Size = new System.Drawing.Size(645, 341);
            this.tPageCadUsuario.TabIndex = 0;
            this.tPageCadUsuario.Text = "Dados";
            this.tPageCadUsuario.UseVisualStyleBackColor = true;
            // 
            // btAdicNovoEnderCadUsu
            // 
            this.btAdicNovoEnderCadUsu.Location = new System.Drawing.Point(400, 183);
            this.btAdicNovoEnderCadUsu.Name = "btAdicNovoEnderCadUsu";
            this.btAdicNovoEnderCadUsu.Size = new System.Drawing.Size(75, 23);
            this.btAdicNovoEnderCadUsu.TabIndex = 26;
            this.btAdicNovoEnderCadUsu.Text = "Adicionar";
            this.btAdicNovoEnderCadUsu.UseVisualStyleBackColor = true;
            this.btAdicNovoEnderCadUsu.Click += new System.EventHandler(this.btAdicNovoEnderCadUsu_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(531, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 25;
            this.label2.Text = "Data de Nasc.";
            // 
            // mskTxtDtNascCadUsu
            // 
            this.mskTxtDtNascCadUsu.Location = new System.Drawing.Point(534, 39);
            this.mskTxtDtNascCadUsu.Mask = "00/00/0000";
            this.mskTxtDtNascCadUsu.Name = "mskTxtDtNascCadUsu";
            this.mskTxtDtNascCadUsu.Size = new System.Drawing.Size(90, 20);
            this.mskTxtDtNascCadUsu.TabIndex = 24;
            this.mskTxtDtNascCadUsu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mskTxtDtNascCadUsu.ValidatingType = typeof(System.DateTime);
            // 
            // lblMuniCadUsu
            // 
            this.lblMuniCadUsu.AutoSize = true;
            this.lblMuniCadUsu.Location = new System.Drawing.Point(309, 279);
            this.lblMuniCadUsu.Name = "lblMuniCadUsu";
            this.lblMuniCadUsu.Size = new System.Drawing.Size(54, 13);
            this.lblMuniCadUsu.TabIndex = 23;
            this.lblMuniCadUsu.Text = "Município";
            // 
            // lblUfCadUsu
            // 
            this.lblUfCadUsu.AutoSize = true;
            this.lblUfCadUsu.Location = new System.Drawing.Point(603, 279);
            this.lblUfCadUsu.Name = "lblUfCadUsu";
            this.lblUfCadUsu.Size = new System.Drawing.Size(21, 13);
            this.lblUfCadUsu.TabIndex = 22;
            this.lblUfCadUsu.Text = "UF";
            // 
            // txtUfcadUsu
            // 
            this.txtUfcadUsu.Location = new System.Drawing.Point(590, 295);
            this.txtUfcadUsu.Name = "txtUfcadUsu";
            this.txtUfcadUsu.Size = new System.Drawing.Size(34, 20);
            this.txtUfcadUsu.TabIndex = 21;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(312, 295);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(254, 20);
            this.textBox2.TabIndex = 20;
            // 
            // lblBairroCadUsu
            // 
            this.lblBairroCadUsu.AutoSize = true;
            this.lblBairroCadUsu.Location = new System.Drawing.Point(21, 279);
            this.lblBairroCadUsu.Name = "lblBairroCadUsu";
            this.lblBairroCadUsu.Size = new System.Drawing.Size(34, 13);
            this.lblBairroCadUsu.TabIndex = 19;
            this.lblBairroCadUsu.Text = "Bairro";
            // 
            // txtBairroCadUsu
            // 
            this.txtBairroCadUsu.Location = new System.Drawing.Point(24, 295);
            this.txtBairroCadUsu.Name = "txtBairroCadUsu";
            this.txtBairroCadUsu.Size = new System.Drawing.Size(265, 20);
            this.txtBairroCadUsu.TabIndex = 18;
            // 
            // lblComplCadUsu
            // 
            this.lblComplCadUsu.AutoSize = true;
            this.lblComplCadUsu.Location = new System.Drawing.Point(478, 224);
            this.lblComplCadUsu.Name = "lblComplCadUsu";
            this.lblComplCadUsu.Size = new System.Drawing.Size(71, 13);
            this.lblComplCadUsu.TabIndex = 17;
            this.lblComplCadUsu.Text = "Complemento";
            // 
            // txtComplCadUsu
            // 
            this.txtComplCadUsu.Location = new System.Drawing.Point(481, 240);
            this.txtComplCadUsu.Name = "txtComplCadUsu";
            this.txtComplCadUsu.Size = new System.Drawing.Size(143, 20);
            this.txtComplCadUsu.TabIndex = 16;
            // 
            // lblNumCadUsu
            // 
            this.lblNumCadUsu.AutoSize = true;
            this.lblNumCadUsu.Location = new System.Drawing.Point(358, 224);
            this.lblNumCadUsu.Name = "lblNumCadUsu";
            this.lblNumCadUsu.Size = new System.Drawing.Size(44, 13);
            this.lblNumCadUsu.TabIndex = 15;
            this.lblNumCadUsu.Text = "Número";
            // 
            // txtNumCadUsu
            // 
            this.txtNumCadUsu.Location = new System.Drawing.Point(361, 240);
            this.txtNumCadUsu.Name = "txtNumCadUsu";
            this.txtNumCadUsu.Size = new System.Drawing.Size(100, 20);
            this.txtNumCadUsu.TabIndex = 14;
            // 
            // txtLogradCadUsu
            // 
            this.txtLogradCadUsu.Location = new System.Drawing.Point(24, 240);
            this.txtLogradCadUsu.Name = "txtLogradCadUsu";
            this.txtLogradCadUsu.Size = new System.Drawing.Size(316, 20);
            this.txtLogradCadUsu.TabIndex = 13;
            // 
            // lblLogradCadUsu
            // 
            this.lblLogradCadUsu.AutoSize = true;
            this.lblLogradCadUsu.Location = new System.Drawing.Point(21, 224);
            this.lblLogradCadUsu.Name = "lblLogradCadUsu";
            this.lblLogradCadUsu.Size = new System.Drawing.Size(61, 13);
            this.lblLogradCadUsu.TabIndex = 12;
            this.lblLogradCadUsu.Text = "Logradouro";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(24, 183);
            this.maskedTextBox1.Mask = "99,999-999";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(70, 20);
            this.maskedTextBox1.TabIndex = 11;
            // 
            // lblCepCadUsu
            // 
            this.lblCepCadUsu.AutoSize = true;
            this.lblCepCadUsu.Location = new System.Drawing.Point(21, 167);
            this.lblCepCadUsu.Name = "lblCepCadUsu";
            this.lblCepCadUsu.Size = new System.Drawing.Size(28, 13);
            this.lblCepCadUsu.TabIndex = 10;
            this.lblCepCadUsu.Text = "CEP";
            // 
            // mskTxtTelCadUsu
            // 
            this.mskTxtTelCadUsu.Location = new System.Drawing.Point(534, 97);
            this.mskTxtTelCadUsu.Mask = "(99) 09999-9999";
            this.mskTxtTelCadUsu.Name = "mskTxtTelCadUsu";
            this.mskTxtTelCadUsu.Size = new System.Drawing.Size(90, 20);
            this.mskTxtTelCadUsu.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(531, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Telefone";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(270, 97);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(244, 20);
            this.txtEmail.TabIndex = 7;
            // 
            // lblEmailCadUsu
            // 
            this.lblEmailCadUsu.AutoSize = true;
            this.lblEmailCadUsu.Location = new System.Drawing.Point(267, 81);
            this.lblEmailCadUsu.Name = "lblEmailCadUsu";
            this.lblEmailCadUsu.Size = new System.Drawing.Size(35, 13);
            this.lblEmailCadUsu.TabIndex = 6;
            this.lblEmailCadUsu.Text = "E-mail";
            // 
            // txtNomCadUsu
            // 
            this.txtNomCadUsu.Location = new System.Drawing.Point(24, 97);
            this.txtNomCadUsu.Name = "txtNomCadUsu";
            this.txtNomCadUsu.Size = new System.Drawing.Size(227, 20);
            this.txtNomCadUsu.TabIndex = 5;
            // 
            // lblNomCadUsu
            // 
            this.lblNomCadUsu.AutoSize = true;
            this.lblNomCadUsu.Location = new System.Drawing.Point(21, 81);
            this.lblNomCadUsu.Name = "lblNomCadUsu";
            this.lblNomCadUsu.Size = new System.Drawing.Size(35, 13);
            this.lblNomCadUsu.TabIndex = 4;
            this.lblNomCadUsu.Text = "Nome";
            // 
            // txtIdCadUsu
            // 
            this.txtIdCadUsu.Location = new System.Drawing.Point(24, 39);
            this.txtIdCadUsu.Name = "txtIdCadUsu";
            this.txtIdCadUsu.Size = new System.Drawing.Size(100, 20);
            this.txtIdCadUsu.TabIndex = 3;
            // 
            // lblCodCadUsu
            // 
            this.lblCodCadUsu.AutoSize = true;
            this.lblCodCadUsu.Location = new System.Drawing.Point(21, 23);
            this.lblCodCadUsu.Name = "lblCodCadUsu";
            this.lblCodCadUsu.Size = new System.Drawing.Size(53, 13);
            this.lblCodCadUsu.TabIndex = 2;
            this.lblCodCadUsu.Text = "Id usuário";
            // 
            // rbtEnderComCadUsu
            // 
            this.rbtEnderComCadUsu.AutoSize = true;
            this.rbtEnderComCadUsu.Location = new System.Drawing.Point(270, 183);
            this.rbtEnderComCadUsu.Name = "rbtEnderComCadUsu";
            this.rbtEnderComCadUsu.Size = new System.Drawing.Size(120, 17);
            this.rbtEnderComCadUsu.TabIndex = 1;
            this.rbtEnderComCadUsu.TabStop = true;
            this.rbtEnderComCadUsu.Text = "Endereço Comercial";
            this.rbtEnderComCadUsu.UseVisualStyleBackColor = true;
            // 
            // rbtEnderResidCadUsu
            // 
            this.rbtEnderResidCadUsu.AutoSize = true;
            this.rbtEnderResidCadUsu.Location = new System.Drawing.Point(122, 183);
            this.rbtEnderResidCadUsu.Name = "rbtEnderResidCadUsu";
            this.rbtEnderResidCadUsu.Size = new System.Drawing.Size(129, 17);
            this.rbtEnderResidCadUsu.TabIndex = 0;
            this.rbtEnderResidCadUsu.TabStop = true;
            this.rbtEnderResidCadUsu.Text = "Endereço Residencial";
            this.rbtEnderResidCadUsu.UseVisualStyleBackColor = true;
            // 
            // tCadaUsuarioEnder
            // 
            this.tCadaUsuarioEnder.Controls.Add(this.dataGridView1);
            this.tCadaUsuarioEnder.Location = new System.Drawing.Point(4, 22);
            this.tCadaUsuarioEnder.Name = "tCadaUsuarioEnder";
            this.tCadaUsuarioEnder.Padding = new System.Windows.Forms.Padding(3);
            this.tCadaUsuarioEnder.Size = new System.Drawing.Size(645, 341);
            this.tCadaUsuarioEnder.TabIndex = 1;
            this.tCadaUsuarioEnder.Text = "Endereço";
            this.tCadaUsuarioEnder.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(18, 23);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(598, 295);
            this.dataGridView1.TabIndex = 0;
            // 
            // btNovoUsuCad
            // 
            this.btNovoUsuCad.Location = new System.Drawing.Point(63, 25);
            this.btNovoUsuCad.Name = "btNovoUsuCad";
            this.btNovoUsuCad.Size = new System.Drawing.Size(98, 23);
            this.btNovoUsuCad.TabIndex = 2;
            this.btNovoUsuCad.Text = "Novo";
            this.btNovoUsuCad.UseVisualStyleBackColor = true;
            this.btNovoUsuCad.Click += new System.EventHandler(this.btNovoUsuCad_Click);
            // 
            // btConsUsuCad
            // 
            this.btConsUsuCad.Location = new System.Drawing.Point(186, 25);
            this.btConsUsuCad.Name = "btConsUsuCad";
            this.btConsUsuCad.Size = new System.Drawing.Size(98, 23);
            this.btConsUsuCad.TabIndex = 3;
            this.btConsUsuCad.Text = " Consulta";
            this.btConsUsuCad.UseVisualStyleBackColor = true;
            // 
            // btAltUsuCad
            // 
            this.btAltUsuCad.Location = new System.Drawing.Point(299, 25);
            this.btAltUsuCad.Name = "btAltUsuCad";
            this.btAltUsuCad.Size = new System.Drawing.Size(98, 23);
            this.btAltUsuCad.TabIndex = 4;
            this.btAltUsuCad.Text = "Alterar";
            this.btAltUsuCad.UseVisualStyleBackColor = true;
            // 
            // btExclUsuCad
            // 
            this.btExclUsuCad.Location = new System.Drawing.Point(416, 25);
            this.btExclUsuCad.Name = "btExclUsuCad";
            this.btExclUsuCad.Size = new System.Drawing.Size(98, 23);
            this.btExclUsuCad.TabIndex = 5;
            this.btExclUsuCad.Text = "Excluir";
            this.btExclUsuCad.UseVisualStyleBackColor = true;
            // 
            // btFechaFormCadUsu
            // 
            this.btFechaFormCadUsu.Location = new System.Drawing.Point(563, 25);
            this.btFechaFormCadUsu.Name = "btFechaFormCadUsu";
            this.btFechaFormCadUsu.Size = new System.Drawing.Size(98, 23);
            this.btFechaFormCadUsu.TabIndex = 6;
            this.btFechaFormCadUsu.Text = "Fechar";
            this.btFechaFormCadUsu.UseVisualStyleBackColor = true;
            // 
            // btConfirmCadUsu
            // 
            this.btConfirmCadUsu.Location = new System.Drawing.Point(230, 471);
            this.btConfirmCadUsu.Name = "btConfirmCadUsu";
            this.btConfirmCadUsu.Size = new System.Drawing.Size(75, 23);
            this.btConfirmCadUsu.TabIndex = 7;
            this.btConfirmCadUsu.Text = "OK";
            this.btConfirmCadUsu.UseVisualStyleBackColor = true;
            this.btConfirmCadUsu.Click += new System.EventHandler(this.btConfirmCadUsu_Click);
            // 
            // btCancelCadUsu
            // 
            this.btCancelCadUsu.Location = new System.Drawing.Point(322, 471);
            this.btCancelCadUsu.Name = "btCancelCadUsu";
            this.btCancelCadUsu.Size = new System.Drawing.Size(75, 23);
            this.btCancelCadUsu.TabIndex = 8;
            this.btCancelCadUsu.Text = "Cancelar";
            this.btCancelCadUsu.UseVisualStyleBackColor = true;
            // 
            // FCadastroUsuário
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 538);
            this.Controls.Add(this.btCancelCadUsu);
            this.Controls.Add(this.btConfirmCadUsu);
            this.Controls.Add(this.btFechaFormCadUsu);
            this.Controls.Add(this.btExclUsuCad);
            this.Controls.Add(this.btAltUsuCad);
            this.Controls.Add(this.btConsUsuCad);
            this.Controls.Add(this.btNovoUsuCad);
            this.Controls.Add(this.tControlCadUsuario);
            this.Controls.Add(this.statusStrip1);
            this.Name = "FCadastroUsuário";
            this.Text = "System Cadastro de Usuário";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tControlCadUsuario.ResumeLayout(false);
            this.tPageCadUsuario.ResumeLayout(false);
            this.tPageCadUsuario.PerformLayout();
            this.tCadaUsuarioEnder.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Windows.Forms.StatusStrip statusStrip1;
        private Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private Windows.Forms.TabControl tControlCadUsuario;
        private Windows.Forms.TabPage tPageCadUsuario;
        private Windows.Forms.TabPage tCadaUsuarioEnder;
        private Windows.Forms.Button btNovoUsuCad;
        private Windows.Forms.Button btConsUsuCad;
        private Windows.Forms.Button btAltUsuCad;
        private Windows.Forms.Button btExclUsuCad;
        private Windows.Forms.Button btFechaFormCadUsu;
        private Windows.Forms.MaskedTextBox mskTxtTelCadUsu;
        private Windows.Forms.Label label1;
        private Windows.Forms.TextBox txtEmail;
        private Windows.Forms.Label lblEmailCadUsu;
        private Windows.Forms.TextBox txtNomCadUsu;
        private Windows.Forms.Label lblNomCadUsu;
        private Windows.Forms.TextBox txtIdCadUsu;
        private Windows.Forms.Label lblCodCadUsu;
        private Windows.Forms.RadioButton rbtEnderComCadUsu;
        private Windows.Forms.RadioButton rbtEnderResidCadUsu;
        private Windows.Forms.Button btAdicNovoEnderCadUsu;
        private Windows.Forms.Label label2;
        private Windows.Forms.MaskedTextBox mskTxtDtNascCadUsu;
        private Windows.Forms.Label lblMuniCadUsu;
        private Windows.Forms.Label lblUfCadUsu;
        private Windows.Forms.TextBox txtUfcadUsu;
        private Windows.Forms.TextBox textBox2;
        private Windows.Forms.Label lblBairroCadUsu;
        private Windows.Forms.TextBox txtBairroCadUsu;
        private Windows.Forms.Label lblComplCadUsu;
        private Windows.Forms.TextBox txtComplCadUsu;
        private Windows.Forms.Label lblNumCadUsu;
        private Windows.Forms.TextBox txtNumCadUsu;
        private Windows.Forms.TextBox txtLogradCadUsu;
        private Windows.Forms.Label lblLogradCadUsu;
        private Windows.Forms.MaskedTextBox maskedTextBox1;
        private Windows.Forms.Label lblCepCadUsu;
        private Windows.Forms.DataGridView dataGridView1;
        private Windows.Forms.Button btConfirmCadUsu;
        private Windows.Forms.Button btCancelCadUsu;
    }
}