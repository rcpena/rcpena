﻿namespace System.CadastroUsuario
{
    internal class clendereco
    {
    }
}