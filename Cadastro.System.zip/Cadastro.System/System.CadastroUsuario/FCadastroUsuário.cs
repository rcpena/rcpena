﻿using System;
using System.CadastroUsuario.Entity;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace System.CadastroUsuario
{
    public partial class FCadastroUsuário : Form
    {
        public FCadastroUsuário()
        {
            InitializeComponent();
            btAdicNovoEnderCadUsu.Enabled = false;
            btConfirmCadUsu.Enabled = false;
            btCancelCadUsu.Enabled = false;
            rbtEnderResidCadUsu.Checked = false;
            rbtEnderComCadUsu.Checked = false;
        }

        private void btNovoUsuCad_Click(object sender, EventArgs e)
        {

            txtNomCadUsu.Clear();
            txtBairroCadUsu.Clear();
            txtComplCadUsu.Clear();
            txtLogradCadUsu.Clear();
            txtNumCadUsu.Clear();
            txtUfcadUsu.Clear();
            mskTxtDtNascCadUsu.Clear();
            mskTxtTelCadUsu.Clear();
            rbtEnderResidCadUsu.Checked = false;
            rbtEnderComCadUsu.Checked = false;
            btConfirmCadUsu.Enabled = true;
            btCancelCadUsu.Enabled = true;
                      

        }

        private void btAdicNovoEnderCadUsu_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ok");
        }

        private void btConfirmCadUsu_Click(object sender, EventArgs e)
        {
            Clusuario objForm = new Clusuario();
            objForm.Id = '0';
            objForm.Nome = txtNomCadUsu.Text;
            objForm.DtNascimento = '0';
            objForm.Email = txtEmail.Text;

            clendereco FormEnder = new clendereco();
            FormEnder.

        }
    }
}
