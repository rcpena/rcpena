﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.CadastroUsuario.DAO;
using MySql.Data.MySqlClient;

namespace System.CadastroUsuario.DAO
{
    class ClassDao
    {
        string conec = "SERVER=localhost; DATABASE= dbteste; UID=root;PWD=; PORT=;";

        public MySqlConnection con = null;

        public void OpenConec()
        {
            try
            {
                con = new MySqlConnection(conec);
                con.Open();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void CloseConec()
        {
            try
            {
                con = new MySqlConnection(conec);
                con.Close();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }





    }



}
