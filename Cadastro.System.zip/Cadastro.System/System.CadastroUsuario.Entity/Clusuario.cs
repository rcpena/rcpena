﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace System.CadastroUsuario.Entity
{
    public class Clusuario
    {
        private int id;
        private string nome;
        private DateTime dtNascimento;
        private string email;
        private int dddTelefone;
        private string numTelefone;

       
        public int Id { get => id; set => id = value; }
        public string Nome { get => nome; set => nome = value; }
        public DateTime DtNascimento { get => dtNascimento; set => dtNascimento = value; }
        public string Email { get => email; set => email = value; }
        public int DddTelefone { get => dddTelefone; set => dddTelefone = value; }
        public string NumTelefone { get => numTelefone; set => numTelefone = value; }
    }
}
 