﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace System.CadastroUsuario.Entity
{
    class Cltelefone
    {
        private int idTelefone;
        private int dddTelefone;
        private string numTelefone;

        public int IdTelefone { get => idTelefone; set => idTelefone = value; }
        public int DddTelefone { get => dddTelefone; set => dddTelefone = value; }
        public string NumTelefone { get => numTelefone; set => numTelefone = value; }
    }
}
