﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace System.CadastroUsuario.Entity
{
    class Clendereco
    {
        private int idEndereco;
        private int cepEnder;
        private string logradouroEnder;
        private int numEnder;
        private string complementoEnder;
        private string bairroEnder;
        private string muncipioEnder;
        private char ufEnder;

        public int IdEndereco { get => idEndereco; set => idEndereco = value; }
        public int CepEnder { get => cepEnder; set => cepEnder = value; }
        public string LogradouroEnder { get => logradouroEnder; set => logradouroEnder = value; }
        public int NumEnder { get => numEnder; set => numEnder = value; }
        public string ComplementoEnder { get => complementoEnder; set => complementoEnder = value; }
        public string BairroEnder { get => bairroEnder; set => bairroEnder = value; }
        public string MuncipioEnder { get => muncipioEnder; set => muncipioEnder = value; }
        public char UfEnder { get => ufEnder; set => ufEnder = value; }
    }
}
